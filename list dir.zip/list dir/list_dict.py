#import the csv and json
import csv
import json

#defining input list of dict
list_of_dict = 	[
	{
		"Test_SECI250_NCU01": {
			"source": "bcu_md",
			"col": "bcu_id",
			"value": "SECI250_NCU01_BOT02"
		}
	},
	{
		"Test_SECI250_NCU01": {
			"source": "bcu_md",
			"col": "bcu_id",
			"value": "SECI250_NCU01_BOT01"
		}
	},
	{
		"Test_SECI250_NCU01": {
			"source": "bcu_md",
			"col": "bcu_id",
			"value": "SECI250_NCU01_BOT03"
		}
	},
	{
		"Test_SECI250_NCU01": {
			"source": "bcu_md",
			"col": "bcu_id",
			"value": "SECI250_NCU01_BOT04"
		}
	},
	{
		"Test_SECI250_NCU01": {
			"source": "bcu_md",
			"col": "bcu_id",
			"value": "SECI250_NCU01_BOT05"
		}
	},
	{
		"SECI250": {
			"source": "ncu_md",
			"col": "ncu_id",
			"value": "Test_SECI250_NCU01"
		}
	},
	{
		"Champagne-Ardenne": {
			"source": "plant_md",
			"col": "plant_nm",
			"value": "SECI250"
		}
	},
	{
		"France": {
			"source": "state_md",
			"col": "state_nm",
			"value": "Champagne-Ardenne"
		}
	},
	{
		"Western Europe": {
			"source": "country_md",
			"col": "country_nm",
			"value": "France"
		}
	},
	{
		"Test_Mahindra": {
			"source": "region_md",
			"col": "region_nm",
			"value": "Western Europe"
		}
	},
	{
		"root": {
			"source": "customer_md",
			"col": "cust_nm",
			"value": "Test_Mahindra"
		}
	}
]


#reduced space complexity by direcly loading list of dict to variable
#if file is list of dict with proper json format at end deco aproach is given


#defining col names
col_name = ['parent', 'child']

#creating and opening an empty csv
with open("output.csv", 'a') as csvfile:

    # col_name = ['parent', 'child']
    writer = csv.DictWriter(csvfile, fieldnames = col_name)
    writer.writeheader()

    list_of_dict = list_of_dict[::-1]
    for i in range(len(list_of_dict)):
    # print(list_of_dict[i])
        for j,k in list_of_dict[i].items():
            # print([j,k["value"]])
            writer.writerow({'parent' : j,
                            'child': k["value"]})



#demo aproach if the json or dict is huge file
"""with open("test.json", "r") as file:#open file
    #load with json file
    data = json.loads(file.readlines())

    # use below method if the file doen't not followed the json format
    data = json.dump(file)

    # remailning as usual iterating by looping and printing dict values.
"""